/* =========================================
   EDIT THESE LINES FIRST
   ========================================= */
const CONFIG = {
  passcode: "0809",            // lock screen ka passcode
  hisName: "Your Love",        // tumhara naam (WhatsApp message mein aayega)
  birthdayDate: "",            // "2026-12-15" format. Calendar mein 🎂 dikhega
  whatsappNumber: ""           // e.g. "923001234567" (+ ke bagair). Khali ho to contact choose hoga
};

/* ---------- Helpers ---------- */
const $ = (id) => document.getElementById(id);
const pages = [
  "page-lock",      // 0
  "page-garden",    // 1
  "page-birthday",  // 2
  "page-message",   // 3
  "page-ask",       // 4
  "page-calendar",  // 5
  "page-plan",      // 6
  "page-thanks"     // 7
];
const FIRST_DOT_PAGE = 2; // dots birthday page se dikhenge

/* ---------- Progress dots ---------- */
const dotsEl = $("dots");
pages.slice(FIRST_DOT_PAGE).forEach(() => dotsEl.appendChild(document.createElement("span")));

function go(index) {
  pages.forEach((id, i) => {
    const el = $(id);
    el.classList.toggle("active", i === index);
    el.classList.remove("enter");
    if (i === index) {
      void el.offsetWidth; // restart animation
      el.classList.add("enter");
    }
  });
  dotsEl.classList.toggle("hidden", index < FIRST_DOT_PAGE);
  [...dotsEl.children].forEach((d, i) => d.classList.toggle("on", i === index - FIRST_DOT_PAGE));
  window.scrollTo({ top: 0 });
}
go(0);

/* ---------- Floating hearts ---------- */
const heartsEl = $("hearts");
const emojis = ["💗", "💕", "💖", "🌸", "❤️"];
let heartsOn = false;

function makeHeart() {
  const h = document.createElement("div");
  h.className = "floating";
  h.textContent = emojis[Math.floor(Math.random() * emojis.length)];
  h.style.left = Math.random() * 100 + "vw";
  h.style.fontSize = 18 + Math.random() * 22 + "px";
  h.style.animationDuration = 4 + Math.random() * 4 + "s";
  heartsEl.appendChild(h);
  setTimeout(() => h.remove(), 8000);
}
setInterval(() => { if (heartsOn) makeHeart(); }, 450);

function burst(n = 30) {
  for (let i = 0; i < n; i++) setTimeout(makeHeart, i * 70);
}

/* ---------- Page 0: Lock screen ---------- */
let entered = "";
const pinDots = document.querySelectorAll("#pin i");
const lockCard = $("lockCard");
const lockHint = $("lockHint");

function renderPin() {
  pinDots.forEach((d, i) => d.classList.toggle("on", i < entered.length));
}

function checkPin() {
  if (entered === CONFIG.passcode) {
    $("lockIcon").textContent = "🔓";
    $("lockIcon").classList.add("open");
    lockHint.textContent = "Unlocked! 💖";
    setTimeout(startGarden, 700);
  } else {
    lockCard.classList.remove("wrong", "shake");
    void lockCard.offsetWidth;
    lockCard.classList.add("wrong", "shake");
    lockHint.textContent = "Galat passcode, dobara try karo 🙈";
    entered = "";
    setTimeout(renderPin, 250);
  }
}

$("keypad").addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  const key = btn.dataset.key;
  lockCard.classList.remove("wrong", "shake");

  if (key === "clear") entered = "";
  else if (key === "back") entered = entered.slice(0, -1);
  else if (entered.length < CONFIG.passcode.length) entered += key;

  renderPin();
  if (entered.length === CONFIG.passcode.length) setTimeout(checkPin, 150);
});

/* ---------- Page 1: Flower garden ---------- */
const bloomEmojis = ["🌸", "🌷", "🌹", "🌻", "🌼", "💐", "🌺", "🪻"];

function startGarden() {
  go(1);
  const field = $("gardenField");
  field.innerHTML = "";

  const count = window.innerWidth < 500 ? 16 : 28;
  for (let i = 0; i < count; i++) {
    const delay = Math.random() * 2.2;
    const height = 90 + Math.random() * (window.innerHeight * 0.45);
    const size = 34 + Math.random() * 30;

    const f = document.createElement("div");
    f.className = "flower";
    f.style.left = (3 + (i / (count - 1)) * 94) + "%";
    f.style.animationDelay = (-Math.random() * 3) + "s";

    const stem = document.createElement("div");
    stem.className = "stem";
    stem.style.setProperty("--h", height + "px");
    stem.style.animationDelay = delay + "s";

    const leaf = document.createElement("div");
    leaf.className = "leaf";
    leaf.style.bottom = height * 0.35 + "px";
    leaf.style.left = (i % 2 ? 2 : -16) + "px";
    leaf.style.animationDelay = delay + 1 + "s";
    if (i % 2 === 0) leaf.style.transform = "scaleX(-1)";

    const bloom = document.createElement("div");
    bloom.className = "bloom";
    bloom.textContent = bloomEmojis[Math.floor(Math.random() * bloomEmojis.length)];
    bloom.style.fontSize = size + "px";
    bloom.style.bottom = height + "px";
    bloom.style.animationDelay = delay + 1.6 + "s";

    f.append(stem, leaf, bloom);
    field.appendChild(f);
  }

  setTimeout(() => {
    heartsOn = true;
    burst(45);
    go(2);
  }, 6500);
}

/* ---------- Generic Next buttons (data-next="pageIndex") ---------- */
document.querySelectorAll("[data-next]").forEach((btn) => {
  btn.addEventListener("click", () => {
    burst(30);
    go(Number(btn.dataset.next));
  });
});

/* ---------- Page 4: Date question ---------- */
const yes = $("yes");
const no = $("no");

function dodgeNo() {
  const x = Math.random() * 160 - 80;
  const y = Math.random() * 120 - 60;
  no.style.transform = `translate(${x}px, ${y}px)`;
}
no.addEventListener("pointerenter", dodgeNo);
no.addEventListener("click", dodgeNo);
no.addEventListener("touchstart", (e) => { e.preventDefault(); dodgeNo(); }, { passive: false });

yes.addEventListener("click", () => {
  burst(50);
  go(5);
});

/* ---------- Page 5: Calendar ---------- */
const today = new Date();
today.setHours(0, 0, 0, 0);
let view = new Date(today.getFullYear(), today.getMonth(), 1);
let selectedDate = null;

const pad = (n) => String(n).padStart(2, "0");
const keyOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

function renderCalendar() {
  $("monthLabel").textContent = view.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  const daysEl = $("days");
  daysEl.innerHTML = "";

  const firstDay = view.getDay();
  const total = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();

  for (let i = 0; i < firstDay; i++) daysEl.appendChild(document.createElement("span"));

  for (let d = 1; d <= total; d++) {
    const date = new Date(view.getFullYear(), view.getMonth(), d);
    const key = keyOf(date);
    const btn = document.createElement("button");
    btn.className = "day";
    btn.textContent = d;
    btn.type = "button";
    if (date < today) btn.disabled = true;
    if (date.getTime() === today.getTime()) btn.classList.add("today");
    if (key === CONFIG.birthdayDate) btn.classList.add("bday");
    if (selectedDate && key === keyOf(selectedDate)) btn.classList.add("selected");
    btn.addEventListener("click", () => selectDate(date));
    daysEl.appendChild(btn);
  }
}

function selectDate(date) {
  selectedDate = date;
  $("pickedText").textContent = "Humari date: " + formatDate(date) + " 💕";
  $("toPlan").disabled = false;
  renderCalendar();
}

function formatDate(d) {
  return d.toLocaleDateString("en-US", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

$("prevMonth").addEventListener("click", () => {
  view = new Date(view.getFullYear(), view.getMonth() - 1, 1);
  renderCalendar();
});
$("nextMonth").addEventListener("click", () => {
  view = new Date(view.getFullYear(), view.getMonth() + 1, 1);
  renderCalendar();
});

if (CONFIG.birthdayDate) {
  const [y, m] = CONFIG.birthdayDate.split("-").map(Number);
  view = new Date(y, m - 1, 1);
}
renderCalendar();

$("toPlan").addEventListener("click", () => go(6));

/* ---------- Page 6: Plan ---------- */
const chosen = new Set();

document.querySelectorAll(".opt").forEach((btn) => {
  btn.addEventListener("click", () => {
    const v = btn.dataset.value;
    if (chosen.has(v)) { chosen.delete(v); btn.classList.remove("selected"); }
    else { chosen.add(v); btn.classList.add("selected"); }
    $("toThanks").disabled = chosen.size === 0;
  });
});

$("toThanks").addEventListener("click", () => {
  const time = $("time").value || "Tum batao";
  const place = $("place").value.trim() || "Surprise 😉";
  const plan = [...chosen].join(", ");
  const dateText = formatDate(selectedDate);

  $("summary").innerHTML = `
    <div><b>📅 Date</b><span>${escapeHtml(dateText)}</span></div>
    <div><b>⏰ Time</b><span>${escapeHtml(time)}</span></div>
    <div><b>📍 Place</b><span>${escapeHtml(place)}</span></div>
    <div><b>💕 Plan</b><span>${escapeHtml(plan)}</span></div>`;

  const msg =
    `💕 IT'S A DATE! 💕\n\n` +
    `📅 ${dateText}\n⏰ ${time}\n📍 ${place}\n💕 ${plan}\n\n` +
    `Can't wait to see you, ${CONFIG.hisName}! ❤️`;

  const base = CONFIG.whatsappNumber ? `https://wa.me/${CONFIG.whatsappNumber}` : "https://wa.me/";
  $("shareBtn").href = `${base}?text=${encodeURIComponent(msg)}`;

  burst(70);
  go(7);
});

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}